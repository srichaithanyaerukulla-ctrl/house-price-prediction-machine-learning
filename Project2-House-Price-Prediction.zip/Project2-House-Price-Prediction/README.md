# House Price Prediction & Data Analysis

A combined data-analysis and machine-learning project that explores a housing
dataset with **Pandas/Matplotlib** and predicts house prices using a
**Linear Regression** model built with **Scikit-learn**.

This single project fulfils both:
- Data analysis & visualization (averages, bar chart, scatter plot, heatmap)
- Linear regression price prediction

## Features

- ✅ Load and preview dataset with Pandas (`housing_data.csv`)
- ✅ Compute averages and descriptive statistics
- ✅ Correlation analysis between features and price
- ✅ Bar chart — average price by number of bedrooms
- ✅ Scatter plot — area vs price
- ✅ Heatmap — correlation matrix of all features
- ✅ Linear Regression model training & evaluation (R², RMSE)
- ✅ Predict price for a new/unseen house
- ✅ Actual vs Predicted visualization

## Technologies Used

- Python 3
- Pandas
- NumPy
- Matplotlib
- Scikit-learn

## Project Structure

```
Project2-House-Price-Prediction/
├── house_price_prediction.py
├── housing_data.csv
├── requirements.txt
├── example_run_output.txt
├── outputs/
│   ├── bar_chart_avg_price_by_bedrooms.png
│   ├── scatter_area_vs_price.png
│   ├── heatmap_correlation.png
│   └── actual_vs_predicted.png
└── README.md
```

## How to Run

```bash
pip install -r requirements.txt
python house_price_prediction.py
```

All charts are saved automatically inside the `outputs/` folder.

## Results Summary

| Metric | Value |
|--------|-------|
| R² Score | ~0.99 |
| RMSE | ~₹1,200 |

The model achieves a high R² score, indicating strong predictive accuracy
on this dataset. Area, location score, and age were found to be the most
strongly correlated features with price.

## Dataset Note

A representative 20-row housing dataset (`housing_data.csv`) is included so
the project runs end-to-end without requiring an external download. The
code is written generically (`pd.read_csv`) so it can be pointed at any
larger real-world dataset (e.g. from Kaggle) by simply replacing the CSV
file — no code changes are required.

## Author

Erukulla Sri Chaithanya
