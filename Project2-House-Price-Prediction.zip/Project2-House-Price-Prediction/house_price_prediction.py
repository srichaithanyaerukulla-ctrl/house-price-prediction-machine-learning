"""
House Price Prediction & Data Analysis
----------------------------------------
Loads a housing dataset using Pandas, performs exploratory data analysis
and visualization with Matplotlib (bar chart, scatter plot, heatmap),
then trains a Linear Regression model with Scikit-learn to predict
house prices based on Area, Bedrooms, Bathrooms, Location Score and Age.

Author: Erukulla Sri Chaithanya
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

OUTPUT_DIR = "outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ----------------------------------------------------------------------
# 1. DATASET LOADING
# ----------------------------------------------------------------------
DATA_PATH = "housing_data.csv"
df = pd.read_csv(DATA_PATH)

print("=" * 60)
print("STEP 1: DATASET PREVIEW")
print("=" * 60)
print(df.head())
print(f"\nDataset shape: {df.shape}")

# ----------------------------------------------------------------------
# 2. BASIC DATA ANALYSIS
# ----------------------------------------------------------------------
print("\n" + "=" * 60)
print("STEP 2: BASIC DATA ANALYSIS")
print("=" * 60)
print(df.describe())

avg_price = df["Price"].mean()
avg_area = df["Area_sqft"].mean()
print(f"\nAverage House Price: ₹{avg_price:,.2f}")
print(f"Average Area: {avg_area:,.2f} sqft")

print("\nCorrelation of each feature with Price:")
correlation = df.corr(numeric_only=True)["Price"].sort_values(ascending=False)
print(correlation)

# ----------------------------------------------------------------------
# 3. VISUALIZATIONS
# ----------------------------------------------------------------------
print("\n" + "=" * 60)
print("STEP 3: GENERATING VISUALIZATIONS")
print("=" * 60)

# 3a. Bar chart - Average price by bedroom count
plt.figure(figsize=(7, 5))
df.groupby("Bedrooms")["Price"].mean().plot(kind="bar", color="steelblue")
plt.title("Average House Price by Number of Bedrooms")
plt.xlabel("Bedrooms")
plt.ylabel("Average Price (₹)")
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/bar_chart_avg_price_by_bedrooms.png")
plt.close()

# 3b. Scatter plot - Area vs Price
plt.figure(figsize=(7, 5))
plt.scatter(df["Area_sqft"], df["Price"], color="darkorange", edgecolor="black")
plt.title("House Area vs Price")
plt.xlabel("Area (sqft)")
plt.ylabel("Price (₹)")
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/scatter_area_vs_price.png")
plt.close()

# 3c. Heatmap - Correlation matrix
plt.figure(figsize=(7, 6))
corr_matrix = df.corr(numeric_only=True)
plt.imshow(corr_matrix, cmap="coolwarm", interpolation="none")
plt.colorbar(label="Correlation Coefficient")
plt.xticks(range(len(corr_matrix.columns)), corr_matrix.columns, rotation=45, ha="right")
plt.yticks(range(len(corr_matrix.columns)), corr_matrix.columns)
for i in range(len(corr_matrix.columns)):
    for j in range(len(corr_matrix.columns)):
        plt.text(j, i, f"{corr_matrix.iloc[i, j]:.2f}", ha="center", va="center", fontsize=8)
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/heatmap_correlation.png")
plt.close()

print(f"Saved 3 visualization images to '{OUTPUT_DIR}/' folder.")

# ----------------------------------------------------------------------
# 4. LINEAR REGRESSION MODEL
# ----------------------------------------------------------------------
print("\n" + "=" * 60)
print("STEP 4: TRAINING LINEAR REGRESSION MODEL")
print("=" * 60)

features = ["Area_sqft", "Bedrooms", "Bathrooms", "Location_Score", "Age_years"]
X = df[features]
y = df["Price"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Model Coefficients:")
for feat, coef in zip(features, model.coef_):
    print(f"  {feat}: {coef:.2f}")
print(f"Intercept: {model.intercept_:.2f}")

r2 = r2_score(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"\nR² Score: {r2:.4f}")
print(f"RMSE: {rmse:,.2f}")

# ----------------------------------------------------------------------
# 5. PREDICTION ON NEW DATA
# ----------------------------------------------------------------------
print("\n" + "=" * 60)
print("STEP 5: PREDICTING PRICE FOR A NEW HOUSE")
print("=" * 60)

new_house = pd.DataFrame({
    "Area_sqft": [1800],
    "Bedrooms": [3],
    "Bathrooms": [2],
    "Location_Score": [8],
    "Age_years": [7],
})
predicted_price = model.predict(new_house)[0]
print("New house specs:")
print(new_house.to_string(index=False))
print(f"\nPredicted Price: ₹{predicted_price:,.2f}")

# ----------------------------------------------------------------------
# 6. ACTUAL VS PREDICTED VISUALIZATION
# ----------------------------------------------------------------------
plt.figure(figsize=(7, 5))
plt.scatter(y_test, y_pred, color="green", edgecolor="black")
plt.plot([y.min(), y.max()], [y.min(), y.max()], "r--", label="Perfect Prediction")
plt.xlabel("Actual Price (₹)")
plt.ylabel("Predicted Price (₹)")
plt.title("Actual vs Predicted House Prices")
plt.legend()
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/actual_vs_predicted.png")
plt.close()

print(f"\nAll visualizations saved in the '{OUTPUT_DIR}/' folder.")
print("Done.")
